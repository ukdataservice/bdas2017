library(rgdal)
library(leaflet)
require(graphics)

SOU_admin <- readOGR(dsn = "SOU_admin", layer = "SOU", encoding = "UTF-8")

head(SOU_admin@data)


pal <- colorNumeric(palette = "YlGnBu",domain = SOU_admin@data$ID)

# Using a simple field for the popup. It could be more complex HTML
popup <- as.factor(SOU_admin$ID)

# finally draw the map
leaflet(data = SOU_admin) %>%
  addProviderTiles("CartoDB.Positron") %>%
  setView(25, -30, zoom = 6) %>%
  addLegend("bottomright", pal = pal, values = ~ID,
            title = "Admin Regions",
            opacity = 1) %>%
  addPolygons(fillColor = ~pal(ID), 
              fillOpacity = 0.8, 
              color = "#BDBDC3", 
              weight = 1, 
              popup = popup)

#####################################

pal <- colorBin(palette = "Greens",domain = SOU_admin@data$ID, bins = 334)

leaflet(data = SOU_admin) %>%
  addProviderTiles("CartoDB.Positron") %>%
  setView(25, -30, zoom = 6) %>%
  addLegend("bottomright", pal = pal, values = ~ID,
            title = "Admin Regions",
            opacity = 1) %>%
  addPolygons(fillColor = ~pal(ID), 
              fillOpacity = 0.8, 
              color = "#BDBDC3", 
              weight = 1, 
              popup = popup)