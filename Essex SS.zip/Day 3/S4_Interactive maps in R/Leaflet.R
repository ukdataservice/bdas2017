# Install the leaflet package
install.packages("leaflet")


# Load the Leaflet library - only need to do this once

library(leaflet)

#create an empty canvas and assign it to the variable m, display m, ie. show the map

m <- leaflet()
m

# add a default tile ( the whole world) to the canvas
# the %>% is the pipe operator, it allows instructions to be chained together
m <- leaflet() %>%
  addTiles()   
m 

#set a center for the map and an initial zoom level

m <- leaflet() %>%
  addTiles() %>%  
  setView(0, 51.478792, zoom = 12) 
m

# add a marker to the map and provide some txt for it

popup_val <- "Hello Greenwich"
m <- leaflet() %>%
  addTiles() %>%  
  setView(0, 51.478792, zoom = 12) %>%
  addMarkers(lng=0, lat=51.478792, popup=popup_val)
m 

# the text can be HTMLwhich will be interpreted
# in this case the text is in bold and there is a link to a web page

popup_val <- "<b>Hello Greenwich</b><br><a href='https://greenwichmeantime.com/'>All about GMT</a>"
m <- leaflet() %>%
  addTiles() %>%  
  setView(0, 51.478792, zoom = 15) %>%
  addMarkers(lng=0, lat=51.478792, popup=popup_val)
m 

# now we want to place many markers by reading the data from a file 
# and passing the dataframe into the addMarkers function
# because the contents of the PC column is just text, we just see the contents.

aberdeen <- read.csv("Aberdeen_PC.csv")



m <- leaflet() %>%
  addTiles() %>%  
  setView(-2.096647861, 57.14822809, zoom = 12) %>%
  addMarkers(data = aberdeen, lng = ~ Long, lat = ~ Lat, popup = PC)
m

# quite often we want several items of info in the popup
# we can do this by createing an HTML table structure and imbedding the required info.
# in this example we have hand coded the data

popup_val <- paste0("<table width='100%' cellspacing='2' cellpadding='0' border='0' align='center' bgcolor='#ff6600'>
                     <tr>
                        <td><b>Post Code</b></td>
                        <td>AB10 1AA</td>
                     </tr>
                     <tr>
                        <td><b>Name</b></td>
                        <td>George St/Harbour Ward</td>
                     </tr>
                     <tr>
                        <td><b>Admin Code</b></td>
                        <td>S12000033</td>
                     </tr>
                     </table>")

m <- leaflet() %>%
  addTiles() %>%  
  setView(-2.096647861, 57.14822809, zoom = 15) %>%
  addMarkers(lng=-2.096647861, lat=57.14822809, popup=popup_val)
m 

# we can do something similar, but using the data read from the file
# in this case combining 3 different columns from the dataframe

m <- leaflet() %>%
  addTiles() %>%  
  setView(-2.096647861, 57.14822809, zoom = 15) %>%
  addMarkers(data = aberdeen, lng = ~ Long, lat = ~ Lat, 
             popup = paste0("<table width='100%' 
                              cellspacing='2' 
                              cellpadding='0' 
                              border='0' 
                              align='center' 
                              bgcolor='#ff6600'>
                    <tr>
                    <td><b>Post Code</b></td>
                    <td>", aberdeen$PC, "</td>
                    </tr>
                    <tr>
                    <td><b>Name</b></td>
                    <td>", aberdeen$Name, "</td>
                    </tr>
                    <tr>
                    <td><b>Admin Code</b></td>
                    <td>", aberdeen$Admin, "</td>
                    </tr>
                    </table>"))
m 

# the last bit of coding looks a bit messy. 
# As an alternative we could create a new column in the dataframe to hold
# the structure and content of the HTML table for the popups.
# this makes the addMarkers call clearer, but bear in mind, you might 
# be considerabley be adding to the size of the dataframe.

aberdeen$popup <- paste0("<table width='100%' 
                              cellspacing='2' 
                              cellpadding='0' 
                              border='0' 
                              align='center' 
                              bgcolor='#ff6600'>
                    <tr>
                    <td><b>Post Code</b></td>
                    <td>", aberdeen$PC, "</td>
                    </tr>
                    <tr>
                    <td><b>Name</b></td>
                    <td>", aberdeen$Name, "</td>
                    </tr>
                    <tr>
                    <td><b>Admin Code</b></td>
                    <td>", aberdeen$Admin, "</td>
                    </tr>
                    </table>")


m <- leaflet() %>%
  addTiles() %>%  
  setView(-2.096647861, 57.14822809, zoom = 15) %>%
  addMarkers(data = aberdeen, lng = ~ Long, lat = ~ Lat, 
             popup = ~ popup)
m 
# finally, you will have noticed the problem of trying to plot too many
# markers on the map. 
# As an alternative to the addMarkers function, there is the AddCircleMarkers function
# This will group the markers, and automatically split them as you zoom in on the map.

m <- leaflet() %>%
  addTiles() %>%  
  setView(-2.096647861, 57.14822809, zoom = 15) %>%
  addCircleMarkers(data = aberdeen, lng = ~ Long, lat = ~ Lat, radius = 5, 
                   clusterOptions = markerClusterOptions(), popup = ~ popup)
m 
