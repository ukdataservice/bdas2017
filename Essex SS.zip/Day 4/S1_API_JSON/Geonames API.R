# The jsonlite library contains the functions we will use  to process the JSON
library(jsonlite)

#setwd("C:/Users/pfsmy/OneDrive/UoM/SA Summer School/Day 2/API_JSON_convert")



#This is the API call we are going to make
lookup <- "http://api.geonames.org/postalCodeCountryInfoJSON?username=PeterSmyth"

#This makes the call to the API and the JSON returned is placed in the 
# variable rd
rd <- readLines(lookup, warn = "F")

# this is processed to extract the JSON and place it in a more friendly 
# R data structure
dat <- fromJSON(rd)
# which we can look at
str(dat)
# we can also look at the JSON in a more readable format using prettify
prettify(rd, indent = 4)

# we can extract the JSON information into a standard R data frame
# the name of the embedded dataframe won't always be geonames.
# It depends on which Webservice you are using
postalCodeCountryInfo <- dat$geonames



# Post codes
# We can now lookup GB specific postal codes in a very similar fashion


lookup <- "http://api.geonames.org/postalCodeLookupJSON?postalcode=M6&country=GB&maxRows=1000&username=PeterSmyth"

rd <- readLines(lookup, warn = "F")
dat <- (fromJSON(rd))
str(dat)
pcs <- dat$postalcodes

# search for places

# we can combine the outputs from similar searches into a single datatframe

lookup <- "http://api.geonames.org/searchJSON?name_startsWith=SA&country=UK&maxRows=1000&username=PeterSmyth"

rd <- readLines(lookup, warn = "F")
dat <- (fromJSON(rd))
places <- dat$geonames
#prettify(rd, indent = 4)

# The second call is much the same, except at the end we use the rbind function to append the new
# results to the end of the exising data frame

lookup <- "http://api.geonames.org/searchJSON?name_startsWith=TA&country=UK&maxRows=1000&username=PeterSmyth"

rd <- readLines(lookup, warn = "F")
dat <- (fromJSON(rd))
places <- rbind(places, dat$geonames)


# place search

lookup <- "http://api.geonames.org/postalCodeSearchJSON?placename_startsWith=M1&country=UK&maxRows=500&username=PeterSmyth"
rd <- readLines(lookup, warn = "F")
dat <- (fromJSON(rd))
str(dat)
postalcodes <- dat$postalCodes

lookup <- "http://api.geonames.org/postalCodeSearchJSON?placename_startsWith=M2&country=UK&maxRows=500&username=PeterSmyth"
rd <- readLines(lookup, warn = "F")
dat <- (fromJSON(rd))
str(dat)
postalcodes <- rbind(postalcodes, dat$postalCodes)


##############      Twitter   #######

## need to extract from twitter

lookup <- "UKDataService.json"
rd <- readLines(lookup, warn = "F")
dat <- (fromJSON(rd))
prettify(rd, indent = 4)
str(dat)
nrow(dat)
dat$text
dat$entities$user_mentions
dat$entities$user_mentions[377]

x <- data.frame(cbind(dat$id, dat$text))



