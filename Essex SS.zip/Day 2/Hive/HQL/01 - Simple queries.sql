SELECT *
  FROM edrp_geography_data
 LIMIT 10;

SELECT anonid, fueltypes, acorn_type
  FROM edrp_geography_data
 LIMIT 10;


SELECT anonid, fueltypes, acorn_type
  FROM edrp_geography_data
 WHERE fueltypes = "ElecOnly";

SELECT anonid, fueltypes, acorn_type
  FROM edrp_geography_data
 WHERE fueltypes = "ElecOnly" AND acorn_type > 42;

SELECT anonid, fueltypes, acorn_type
  FROM edrp_geography_data
 WHERE fueltypes = "ElecOnly" OR acorn_type > 42;

SELECT anonid, fueltypes, acorn_type
  FROM edrp_geography_data
 WHERE fueltypes = "ElecOnly" AND acorn_type > 42 AND nuts1 <> "--";

SELECT anonid,
       fueltypes,
       acorn_type,
       nuts1,
       ldz
  FROM edrp_geography_data
 WHERE     fueltypes = "ElecOnly"
       AND acorn_type BETWEEN 42 AND 47
       AND (nuts1 NOT IN ("UKM", "UKI") OR ldz = "--");

--  New columns

SELECT anonid,
       eprofileclass,
       acorn_type,
       (eprofileclass * acorn_type) AS multiply,
       (eprofileclass + acorn_type) AS added
  FROM edrp_geography_data b;