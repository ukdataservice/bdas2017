  SELECT anon_id,
         count (eleckwh) AS total_row_count,
         sum (eleckwh) AS total_period_usage,
         min (eleckwh) AS min_period_usage,
         avg (eleckwh) AS avg_period_usage,
         max (eleckwh) AS max_period_usage
    FROM elec_c
GROUP BY anon_id;

  SELECT anon_id,
         substr (advancedatetime, 6, 2) AS reading_year,
         count (eleckwh) AS total_row_count,
         sum (eleckwh) AS total_period_usage,
         min (eleckwh) AS min_period_usage,
         avg (eleckwh) AS avg_period_usage,
         max (eleckwh) AS max_period_usage
    FROM elec_c
GROUP BY anon_id, substr (advancedatetime, 6, 2);

  SELECT anon_id,
         substr (advancedatetime, 6, 2) AS reading_year,
         count (eleckwh) AS total_row_count,
         sum (eleckwh) AS total_period_usage,
         min (eleckwh) AS min_period_usage,
         avg (eleckwh) AS avg_period_usage,
         max (eleckwh) AS max_period_usage
    FROM elec_c
GROUP BY anon_id, substr (advancedatetime, 6, 2)
ORDER BY anon_id, reading_year;

  SELECT anon_id,
         count (eleckwh) AS total_row_count,
         sum (eleckwh) AS total_period_usage,
         min (eleckwh) AS min_period_usage,
         max (eleckwh) AS max_period_usage
    FROM elec_c
GROUP BY anon_id
  HAVING total_row_count > 40000
ORDER BY total_row_count;

SELECT DISTINCT anon_id
  FROM elec_c;

SELECT DISTINCT eprofileclass, fueltypes
  FROM geog_all;