-- Exercises  - New columns, Joins, Subqueries

-- 1 Write a query to create a new column called 'country' for the edrp_geography_data table. 
--   All values of the nuts1 column in the edrp_geography_data table are areas in England apart from "UKM" which is in Scotland
 

 -- 2 Some of the values for nuts1 are given as '--'. Modify the query so that these are listed as 'Unknown' in the Country column  


 
 -- 3 The query below is taken from the notes. Modify it so that instead of using BETWEEN the '>' operator is used.
 






  
  --- joins and subqueries
  
  -- see 06 table joins.sql
    
  
  --- partitioned tables
  