SELECT unix_timestamp () AS currenttime
  FROM sample_07
 LIMIT 1;

SELECT from_unixtime (unix_timestamp ()) AS currenttime
  FROM sample_07
 LIMIT 1;

--    http://www.timeanddate.com/time/zones/ 
SELECT from_utc_timestamp (from_unixtime (unix_timestamp ()), 'EST')
          AS Newtimezone
  FROM sample_07
 LIMIT 1;

  SELECT anon_id,
         from_unixtime (UNIX_TIMESTAMP (reading_date, 'ddMMMyy'))
            AS proper_date
    FROM elec_days_c
ORDER BY proper_date;

  SELECT anon_id,
         from_unixtime (UNIX_TIMESTAMP (reading_date, 'ddMMMyy'))
            AS proper_date,
         year (from_unixtime (UNIX_TIMESTAMP (reading_date, 'ddMMMyy')))
            AS full_year,
         month (from_unixtime (UNIX_TIMESTAMP (reading_date, 'ddMMMyy')))
            AS full_month,
         day (from_unixtime (UNIX_TIMESTAMP (reading_date, 'ddMMMyy')))
            AS full_day,
         last_day (from_unixtime (UNIX_TIMESTAMP (reading_date, 'ddMMMyy')))
            AS last_day_of_month,
         date_add ( (from_unixtime (UNIX_TIMESTAMP (reading_date, 'ddMMMyy'))),
                   10)
            AS added_days
    FROM elec_days_c
ORDER BY proper_date;