CREATE EXTERNAL TABLE elec_dates_partitioned
(
   anon_id           INT,
   advancedatetime   STRING,
   hh                INT,
   eleckwh           DOUBLE,
   day               INT,
   fulldate          STRING
)
PARTITIONED BY
   (month INT,
    year INT)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION 'hdfs://sandbox.hortonworks.com:8020/user/ukdstrain1/elec_dates_partitioned';


SET hive.exec.dynamic.partition = TRUE;
SET hive.exec.dynamic.partition.mode = nonstrict;


INSERT INTO TABLE elec_dates_partitioned PARTITION (month, year)
   SELECT e.anon_id,
          e.advancedatetime,
          e.hh,
          e.eleckwh,
          e.day,
          e.fulldate,
          e.month,
          e.year
     FROM elec_dates e;


-- queries

SELECT count(*)
  FROM elec_dates
 WHERE month = 1 AND year = 2009;

SELECT count(*)
  FROM elec_dates_partitioned
 WHERE month = 1 AND year = 2009;