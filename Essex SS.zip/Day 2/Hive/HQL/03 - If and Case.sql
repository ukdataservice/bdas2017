SELECT anonid,
       elec_tout,
       gas_tout,
       if (elec_tout = 1, elec_tout, gas_tout) AS tout
  FROM edrp_geography_data;

  SELECT anon_id,
         min (monthlykwh) AS minimum,
         max (monthlykwh) AS maximum,
         avg (monthlykwh) AS average,
         max (monthlykwh) - min (monthlykwh) AS rangeofkwh
    FROM elec_months_c
GROUP BY anon_id
ORDER BY rangeofkwh DESC;

SELECT anon_id,
       reading_month,
       monthlykwh,
       CASE
          WHEN monthlykwh BETWEEN 0 AND 400 THEN 'Low'
          WHEN monthlykwh BETWEEN 401 AND 900 THEN 'Medium'
          WHEN monthlykwh BETWEEN 901 AND 1400 THEN 'High'
          ELSE 'Far too high!'
       END
          AS usage_type
  FROM elec_months_c;