 --  Exercises 1 - slice and dice

-- 1. Write a query to select the anonid, fueltypes and acorn_code columns from the geog_c table



-- 2. Modify the query to return only the ‘Dual’ fueltpyes




-- 3. Find out who has used more than 6 kwh of electricity in any half hour period.



-- 4.
-- from the geog_all table, display the anonid, fueltypes, acorn_type, nuts1 and ldz columns
-- where the acorn_type is either 1,2,3,4,5,6,42,43,44,45,46,or 47 and the nuts1 value is neither "UKM" or "UKI" or if it is then the ldz value should be "--"
-- only show the records where the fueltype is "ElecOnly"




-- Exercises 2 New columns, Functions and Alias'

-- 5 write a query to create a Length column to hold the number of characters in the advancedatetime field of the elec_c table




-- 6 find the position of the first "09" string in the advancedatetime field of the elec_c table



-- 7 find the position of the first "09" string after character 6 in the advancedatetime field of the elec_c table


-- 8 Write a query to return all of the electricity readings from the elec_c file where the time is 23:00, limit the output to 50 records




-- 9 From the elec_days_c  table list the rows where the totkwh value is between 10 and 20



--  Aggregations and Distinct

--  10 From the elec_days_c  table count the rows where the totkwh value is between 10 and 20



-- 	11 write a query to find the min, max and sum of the eleckwh columns for each anon_id value from the elec_c  table



-- 12 For the geog_all table, establish, what are the fueltypes and how many records are there for each fueltype?



-- 13 Find all the distinct combinations of eprofileclass and fueltypes in the geog_all table.



-- Date functions

-- 14 using the dates as string, find the min and max dates for each anon_id in the elec_days_c table



-- 15 repeat the above, but convert the string dates into proper dates first



-- 16 find the number of days between the min and max dates and display them in ascending order




