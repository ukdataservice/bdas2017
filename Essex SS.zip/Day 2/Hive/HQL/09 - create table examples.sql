CREATE TABLE smartmeterdata_2728
AS
   SELECT *
     FROM gas_c
    WHERE anon_id = 2728;

SELECT *
  FROM smartmeterdata_2728
 LIMIT 10;

CREATE TABLE smartmeterdata
(
   anon_id           INT,
   advancedatetime   STRING,
   hh                INT,
   gaskwh            DOUBLE
);

CREATE TABLE smartmeterdata_15224
LIKE smartmeterdata;

INSERT OVERWRITE TABLE smartmeterdata_15224
   SELECT *
     FROM gas_c
    WHERE anon_id = 15224;

SELECT count (*)
  FROM smartmeterdata_15224
 LIMIT 10;

-- Loading to/from HDFS  and local files

CREATE TABLE smartmeterdata_from_hdfs
LIKE smartmeterdata;

-- from hdfs data is moved
LOAD DATA  INPATH '/user/ukdstrain1/smartmeterdata_hdfs' OVERWRITE INTO TABLE smartmeterdata_from_hdfs;

-- from local data is copied
-- no OVERWRITE means append
LOAD DATA LOCAL INPATH '/data/smartmeterdata_hdfs'  INTO TABLE smartmeterdata_from_hdfs;

SELECT count (*) FROM smartmeterdata_from_hdfs;

-- Loading to HDFS  and local files

INSERT OVERWRITE DIRECTORY "/user/ukdstrain1/smartmeterdata_hdfs"
   SELECT * FROM smartmeterdata_15224;

INSERT OVERWRITE LOCAL DIRECTORY "/data/smartmeterdata_hdfs"
   SELECT * FROM smartmeterdata_15224;

DROP TABLE smartmeterdata_2;

CREATE EXTERNAL TABLE smartmeterdata_2
(
   anon_id           INT,
   advancedatetime   STRING,
   hh                INT,
   gaskwh            DOUBLE
)
ROW FORMAT DELIMITED
           FIELDS TERMINATED BY ','
           ESCAPED BY '\\'
           LINES TERMINATED BY '\n'
STORED AS TEXTFILE
LOCATION '/user/ukdstrain1/smartmeterdata_2';


SELECT count (*) FROM smartmeterdata_2;

-- use toad to add a data file to the folder 

SELECT *
  FROM smartmeterdata_2
 LIMIT 10;


DROP TABLE smartmeterdata_2 ;  

CREATE EXTERNAL TABLE IF NOT EXISTS smartmeterdata_2
(
   anon_id           INT,
   advancedatetime   STRING,
   hh                INT,
   gaskwh            DOUBLE
)
ROW FORMAT DELIMITED
           FIELDS TERMINATED BY '\001'
           ESCAPED BY '\\'
           LINES TERMINATED BY '\n'
STORED AS TEXTFILE
LOCATION '/user/ukdstrain1/smartmeterdata_2';


SELECT count (*) FROM smartmeterdata_2;

SELECT *
  FROM smartmeterdata_2 
 LIMIT 10;