-- Exercises  - New columns, Joins, Subqueries

-- 1 Write a query to create a new column called 'country' for the edrp_geography_data table. 
--   All values of the nuts1 column in the edrp_geography_data table are areas in England apart from "UKM" which is in Scotland
 
SELECT anonid,
       nuts1,
       if (nuts1 = "UKM", "Scotland", "England") AS country
  FROM edrp_geography_data;

 -- 2 Some of the values for nuts1 are given as '--'. Modify the query so that these are listed as 'Unknown' in the Country column  
  SELECT anonid,
       nuts1,
       if (nuts1 = "UKM", "Scotland", if (nuts1 = "--", "Unknown", "England")) AS country
  FROM edrp_geography_data;

 
 -- 3 The query below is taken from the notes. Modify it so that instead of using BETWEEN the '>' operator is used.
 
  SELECT anon_id,
       reading_month,
       monthlykwh,
       CASE
          WHEN monthlykwh BETWEEN 0 AND 400 THEN 'Low'
          WHEN monthlykwh BETWEEN 401 AND 900 THEN 'Medium'
          WHEN monthlykwh BETWEEN 901 AND 1400 THEN 'High'
          ELSE 'Far too high!'
       END
          AS usage_type
  FROM elec_months_c;




    SELECT anon_id,
       reading_month,
       monthlykwh,
       CASE
          WHEN monthlykwh > 1400 THEN 'Far too high'
          WHEN monthlykwh > 900 THEN 'High'
          WHEN monthlykwh > 400 THEN 'Medium'
          ELSE 'low'
       END
          AS usage_type
  FROM elec_months_c;

  
  --- joins and subqueries
  
  -- see 06 table joins.sql
    
  
  --- partitioned tables
  