SELECT anonid,
       acorn_category,
       acorn_group,
       acorn_type,
       acorn_code,
       concat (acorn_category,
               ",",
               acorn_group,
               ",",
               acorn_type)
          AS acorn_code2
  FROM edrp_geography_data;

SELECT anonid,
       acorn_category,
       acorn_group,
       acorn_type,
       acorn_code,
       concat (acorn_category,
               ",",
               acorn_group,
               ",",
               acorn_type)
          AS acorn_code2
  FROM edrp_geography_data
 WHERE acorn_code = acorn_code2;

SELECT anonid,
       acorn_category,
       acorn_group,
       acorn_type,
       acorn_code,
       concat (acorn_category,
               ",",
               acorn_group,
               ",",
               acorn_type)
          AS acorn_code2
  FROM edrp_geography_data
 WHERE acorn_code = concat (acorn_category,
                            ",",
                            acorn_group,
                            ",",
                            acorn_type);



SELECT anonid,
       acorn_code,
       length (acorn_code),
       instr (acorn_code, ',') AS a_catpos,
       instr (reverse (acorn_code), ",") AS reverse_a_typepos
  FROM edrp_geography_data;

SELECT anon_id,
       advancedatetime,
       substr (advancedatetime, 1, 2) AS day,
       substr (advancedatetime, 3, 3) AS month,
       substr (advancedatetime, 6, 2) AS year
  FROM elec_c;

SELECT anonid,
       substr (acorn_code, 7, 2) AS ac_type_string,
       cast (substr (acorn_code, 7, 2) AS INT) AS ac_type_int,
       substr (acorn_code, 7, 2) +1  AS ac_type_not_sure
  FROM edrp_geography_data;

