CREATE TABLE geog_c
AS
   SELECT *
     FROM edrp_geography_data
    WHERE anonid IN
             (SELECT anonid
                FROM edrp_geography_data
                     TABLESAMPLE (BUCKET 3 OUT OF 150 ON rand (1)));
CREATE TABLE elec_c
AS
   SELECT *
     FROM elec_all e
    WHERE anon_id IN
             (SELECT anonid
                FROM edrp_geography_data
                     TABLESAMPLE (BUCKET 3 OUT OF 150 ON rand (1)) s);
CREATE TABLE gas_c
AS
   SELECT *
     FROM gas_all e
    WHERE anon_id IN
             (SELECT anonid
                FROM edrp_geography_data
                     TABLESAMPLE (BUCKET 3 OUT OF 150 ON rand (1)) s);
SELECT count (*) FROM gas_c;
SELECT count (*) FROM elec_c;
SELECT count (*) FROM geog_c;
