-- Q1
SELECT e.anon_id, g.anon_id
  FROM distinct_elec_c AS e JOIN distinct_gas_c AS g ON e.anon_id = g.anon_id;

--Q2
SELECT e.anon_id, g.anon_id
  FROM distinct_elec_c AS e
       FULL OUTER JOIN distinct_gas_c AS g ON e.anon_id = g.anon_id;

--Q3
CREATE TABLE dual_fueltypes
AS
   SELECT e.anon_id
     FROM distinct_elec_c AS e
          JOIN distinct_gas_c AS g ON e.anon_id = g.anon_id;

--Q4
CREATE TABLE elec_fueltypes
AS
   SELECT e.anon_id
     FROM distinct_elec_c AS e
          LEFT OUTER JOIN distinct_gas_c AS g ON e.anon_id = g.anon_id
    WHERE g.anon_id IS NULL;

--Q5
CREATE TABLE gas_fueltypes
AS
   SELECT g.anon_id
     FROM distinct_elec_c AS e
          RIGHT OUTER JOIN distinct_gas_c AS g ON e.anon_id = g.anon_id
    WHERE e.anon_id IS NULL;

--Q6
SELECT count (*) FROM dual_fueltypes;

--Q7
SELECT count (*) FROM elec_fueltypes;

--Q8
SELECT count (*) FROM gas_fueltypes;

--Q9
SELECT fueltypes, count (*)
    FROM geog_c
GROUP BY fueltypes;


-- using subqueries

--Q10 
SELECT g.anonid 
  FROM geog_c g
 WHERE g.fueltypes = "Dual" and g.anonid NOT IN (SELECT anon_id FROM dual_fueltypes);

--Q11
SELECT anon_id  
  FROM elec_fueltypes
 WHERE anon_id NOT IN (SELECT anonid FROM geog_c where fueltypes = "ElecOnly");


