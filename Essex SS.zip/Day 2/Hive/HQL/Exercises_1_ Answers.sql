 --  Exercises 1 - slice and dice

-- 1. Write a query to select the anonid, fueltypes and acorn_code columns from the geog_c table

SELECT anonid, fueltypes, acorn_code FROM geog_c;

-- 2. Modify the query to return only the ‘Dual’ fueltpyes

SELECT anonid, fueltypes, acorn_code
  FROM geog_c
 WHERE fueltypes = "Dual";


-- 3. Find out who has used more than 6 kwh of electricity in any half hour period.

SELECT anon_id, advancedatetime, eleckwh
  FROM elec_c
 WHERE eleckwh > 6;

-- 4.
-- from the geog_all table, display the anonid, fueltypes, acorn_type, nuts1 and ldz columns
-- where the acorn_type is either 1,2,3,4,5,6,42,43,44,45,46,or 47 and the nuts1 value is neither "UKM" or "UKI" or if it is then the ldz value should be "--"
-- only show the records where the fueltype is "ElecOnly"

SELECT anonid,
       fueltypes,
       acorn_type,
       nuts1,
       ldz
  FROM geog_all
 WHERE     fueltypes = "ElecOnly"
       AND ( (acorn_type BETWEEN 42 AND 47) OR (acorn_type BETWEEN 1 AND 6))
       AND (nuts1 NOT IN ("UKM", "UKI") OR ldz = "--");


-- Exercises 2 New columns, Functions and Alias'

-- 5 write a query to create a Length column to hold the number of characters in the advancedatetime field of the elec_c table

SELECT anon_id, length (advancedatetime) AS length FROM elec_c;


-- 6 find the position of the first "09" string in the advancedatetime field of the elec_c table

SELECT anon_id, advancedatetime, locate ("09", advancedatetime) AS pos
  FROM elec_c;

-- 7 find the position of the first "09" string after character 6 in the advancedatetime field of the elec_c table

SELECT anon_id, advancedatetime, locate ("09", advancedatetime, 6) AS pos
  FROM elec_c;

-- 8 Write a query to return all of the electricity readings from the elec_c file where the time is 23:00, limit the output to 50 records

SELECT *
  FROM elec_c
 WHERE substr (advancedatetime, 9, 5) = "23:00"
 LIMIT 50;


-- 9 From the elec_days_c  table list the rows where the totkwh value is between 10 and 20

SELECT *
  FROM elec_days_c
 WHERE totkwh BETWEEN 10 AND 20;

--  Aggregations and Distinct

--  10 From the elec_days_c  table count the rows where the totkwh value is between 10 and 20

SELECT count (*)
  FROM elec_days_c
 WHERE totkwh BETWEEN 10 AND 20;

-- 	11 write a query to find the min, max and sum of the eleckwh columns for each anon_id value from the elec_c  table

  SELECT anon_id,
         min (eleckwh) AS minkwh,
         max (eleckwh) AS maxkwh,
         sum (eleckwh) AS sumkwh
    FROM elec_c
GROUP BY anon_id;

-- 12 For the geog_all table, establish, what are the fueltypes and how many records are there for each fueltype?

  SELECT fueltypes, count (*) AS fueltypecount
    FROM geog_all
GROUP BY fueltypes;

-- 13 Find all the distinct combinations of eprofileclass and fueltypes in the geog_all table.

SELECT DISTINCT eprofileclass, fueltypes
  FROM geog_all;

-- Date functions

-- 14 using the dates as string, find the min and max dates for each anon_id in the elec_days_c table

  SELECT anon_id, min (reading_date) AS min, max (reading_date) AS max
    FROM elec_days_c
GROUP BY anon_id;

-- 15 repeat the above, but convert the string dates into proper dates first

  SELECT anon_id,
         min (from_unixtime (UNIX_TIMESTAMP (reading_date, 'ddMMMyy'))) AS min,
         max (from_unixtime (UNIX_TIMESTAMP (reading_date, 'ddMMMyy'))) AS max
    FROM elec_days_c
GROUP BY anon_id;

-- 16 find the number of days between the min and max dates and display them in ascending order

  SELECT anon_id,
         min (from_unixtime (UNIX_TIMESTAMP (reading_date, 'ddMMMyy'))) AS min,
         max (from_unixtime (UNIX_TIMESTAMP (reading_date, 'ddMMMyy'))) AS max,
         datediff (
            max (from_unixtime (UNIX_TIMESTAMP (reading_date, 'ddMMMyy'))),
            min (from_unixtime (UNIX_TIMESTAMP (reading_date, 'ddMMMyy'))))
            AS num_days
    FROM elec_days_c
GROUP BY anon_id
ORDER BY num_days ASC;


