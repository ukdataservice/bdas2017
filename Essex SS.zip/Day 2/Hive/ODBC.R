##### load libraries

library(RODBC)
library(ggplot2)
library(scales)
library(Hmisc)
library(utils)

##### set options for display
options(scipen=100)
options(digits=2)


##### Open the odbc connection
channel <- odbcConnect("Sample Hortonworks Hive DSN")

#####  

##### 
hiveTables <- sqlQuery(channel, paste("show tables"))

##### create a dataframe containing the contents of the gdd_2009 table
df1 <- sqlQuery(channel, paste("select * from gdd_2009"))

# add a proper date field
df1$date <- as.Date(paste("01",df1$reading_month,sep=''), format='%d%b%y')


##### create dta to use aggregate data
dta <- aggregate(c(df1$total_period_usage), by=list(df1$month), FUN=sum)
#####   - need to name the columns to something useful
names(dta) <- c("Month", "Usage")


####################   draw graphs   #######################

#######    line graph or NUTS1
ggplot(dta, aes(x=Month, y=Usage)) + 
  geom_line() + 
  geom_point() +
  xlab("2009 Data") + ylab("Gas KWh usage") +
  ggtitle("Gas usage by NUTS1 code for 2009") 



### table creation

df3 <- sqlQuery(channel, paste0("create table df3 as " ,
                               "select * from edrp_geography_data" ,
                                " where nuts4 != '--'"))



# saving a dataframe back to Hive as a new table  *** very very slow *****
df2 <- sqlQuery(channel, paste("select * from geog_c"))
drop <- sqlQuery(channel, paste("drop table df2"))
sqlSave(channel, df2, rownames=FALSE, colnames=FALSE)





